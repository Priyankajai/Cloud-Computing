Lab Number: Assignment 1
Subject:    Cloud Computing
Name:       Priyanka Jayashankar
ID:         1001767668

To launch application run the command 'python hello.py'
The application executes on the port number 8000

Upload the csv file and click submit with the following data:
Name,Points,State,Room,Picture,Salary,Keywords
Betty,500,CA,550,betty.jpg,100000,Keywords
Abhishek,820,TX,420,ab.jpg,100000,"Abhishek is almost done and

very smart"
Ann,820,TX,, ,99099,Ann is not a person
Jason,818,TX,525,jason.jpg,99099,Is smart and hard working
Carol,450,NM,-1, ,99901,Is the name of the ghost in my room
Jees,799,CA,,jees.jpg,99901,Jees is too
Dave,301,NN,520, ,99901,2D
Sue,298,NN,0,ab.jpg,1,You
Darwin,810,OK,101,dar.jpg,1,Did he start the earth?

To get the list of images based on the Salary less than the
given Salary input a integer value and click on search eg: 99000

To get user data Enter the name Eg: Jees and click on search
To update user data search a name and update salary as integer, 
Keywords with some Keywords (String) and Image with jpg or png 
file.