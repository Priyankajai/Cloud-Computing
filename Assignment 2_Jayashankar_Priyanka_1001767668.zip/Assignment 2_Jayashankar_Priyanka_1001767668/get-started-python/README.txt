Lab Number: Assignment 2
Subject:    Cloud Computing
Name:      Priyanka Jayashankar
ID:         1001767668

To run the application run the command 'python application.py'
The application runs on port 5000
Click on "Show all data" to show all data
Click on "Delete all data" to delete all data from database

To upload the data in the database by selecting csv file 
and click on upload. 

To search magnitudes in a range input a magnitude (float)
to and from in the input fields and click search

To search earthquakes in a location range input a range in 
kilometers (integers) and latitude, longitude of a region
(Floats) and click search

To search earthquakes greater than a magnitude input a float 
type in input field and click search

To create a cluster with k-means, input a cluster value (Integer)
and click on searchto get clusters, points in a cluster and centroid 
locations

Click on "When do large earthquakes occur?" to know if earthquakes often 
occur in day or night

To Delete a particular row with timestamp eg:2019-06-07T21:53:18Z and magnitude
from (Integer) and To (Integer)