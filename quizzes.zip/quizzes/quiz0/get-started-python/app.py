"""
Lab Number: Assignment 1
Subject:    Cloud Computing
Name:       Priyanka Jayashankar
ID:         1001767668
References: https://www.w3schools.com/sql
            https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-i-hello-world
            https://github.com/swapniljangampersonal/Cloud-Assignments
            https://github.com/namanjainv/cloud-computing/tree/master/Assignment%201/App
            https://www.tutorialspoint.com/flask/flask_application.htm
"""
from flask import Flask, render_template, request, jsonify
import atexit, os, json, csv
from os.path import isfile,join
import sqlite3

#Configuration
app = Flask(__name__, static_url_path='')
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
port = int(os.getenv('PORT', 8000))

def get_connection():
    return sqlite3.connect('static/mydb')

#Application landing page
@app.route('/')
def root():
    return render_template('index.html')
#Route to upload csv file
@app.route('/uploadcsv', methods=['POST'])
def uploadcsv():
    file = request.files['inputFileCSV']
    destination = os.path.join(APP_ROOT, 'static')
    file.save(os.path.join(destination, file.filename))
    f = open(os.path.join(destination, file.filename), "r")
    reader = csv.DictReader( f, fieldnames = ( "name","salary","telnum","room","picture","keywords"))
    data = [row for row in reader]
    for checkpath in data:
        if not os.path.exists(os.path.join(destination, checkpath['picture'])):
            checkpath['picture'] = "blank.png"
        if not checkpath['picture']:
            checkpath['picture'] = "blank.png"
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DROP TABLE people")
    #cur.execute("CREATE TABLE IF NOT EXISTS people (name varchar(20), points int, state varchar(20), room int, picture varchar(20), salary int, keywords varchar(20))")
    cur.execute("CREATE TABLE IF NOT EXISTS people (name varchar(20), salary int, telnum int, room int, picture varchar(20), keywords varchar(20))")
    for row in data:
        cur.execute("INSERT INTO people VALUES(?, ?, ?, ?, ?, ?)",[row['name'],row['salary'], row['telnum'], row['room'], row['picture'], row['keywords']])
    conn.commit()
    f.close()
    #os.remove(os.path.join(destination, f.filename))
    return "<center><h1>Inserted data</h1></center>"

#Route to get images of people who have salary less than the submitted value
@app.route('/salary', methods=['GET'])
def salary():
    salary = int(request.args['salary'])
    cur = get_connection().cursor()
    cur.execute("SELECT picture FROM people WHERE salary < ?",[salary])
    res = cur.fetchall()
    return render_template("salary.html", result=res)

#Route to get user based on name
@app.route('/user', methods=['GET'])
def user():
    name = request.args['myName']
    cur = get_connection().cursor()
    cur.execute("SELECT * FROM people WHERE name = ?",[name])
    res = cur.fetchone()
    print(res)
    return render_template("user.html", result=res)

#Route to update image of a given user
@app.route('/updateimage', methods=['POST'])
def updateimage():
    file = request.files['user_image']
    file.save(os.path.join('static', file.filename))
    name = request.form['name']
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE people SET picture = ? WHERE name = ? ",[file.filename, name])
    conn.commit()
    return "Record updated"

#Route to update user based on username
@app.route('/updateuser', methods=['POST'])
def updateuser():
    name = request.form['name']
    keywords = request.form['keywords']
    salary = request.form['salary']
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE people SET keywords = ?,salary = ? WHERE name = ? ",[keywords, salary, name])
    conn.commit()
    return "Record Updated"

#Route to delete profile based on the user name
@app.route('/deleteprofile', methods=['GET'])
def deleteuser():
    name = request.args['name']
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM people WHERE name = ?",[name])
    conn.commit()
    return "Record deleted"

#Application startup code
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port, debug=True)
