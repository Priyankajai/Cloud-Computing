"""
Lab Number: Assignment 2
Subject:    Cloud Computing
Name:       Priyanka Jayashankar
ID:         1001767668
"""
from flask import Flask, render_template, request
import ibm_db
import os
import csv
import dateutil.parser
from datetime import datetime, timedelta
from pytz import timezone
import pytz
from timezonefinder import TimezoneFinder
import sqlite3
import math
import numpy
import constants
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
import seaborn as sns

application = Flask(__name__)

#Database configuration
db2conn = ibm_db.connect(
    "DATABASE=BLUDB;HOSTNAME=dashdb-txn-sbox-yp-dal09-10.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=rnc42055;PWD=9085ms-mfqj08bg4", "rnc42055", "9085ms-mfqj08bg4")
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

tf = TimezoneFinder()
fmt = "%Y-%m-%d %H:%M:%S.%f"

print(os.getenv("PORT"))
port = int(os.getenv("PORT", 5000))

#Returns database connection object
def get_connection():
    return db2conn

#Landing page
@application.route('/')
def hello_world():
    return render_template("index.html")

#Magnitude greater than some value
# @application.route('/magGreaterThan', methods=['GET'])
# def greater_than():
#     magTo = request.args['magFrom']
#     conn = get_connection()
#     cur = conn.cursor()
#     cur.execute("SELECT * FROM EARTHQUAKE WHERE "place"="Tonopah" ORDER BY "mytime" LIMIT 4", [magTo])
#     res = cur.fetchall()
#     return render_template('test2.html', result=res)

#Returns earhtquakes based on query parameters
@application.route('/earthquake', methods=['GET'])
def get_earthquakes():
    mag_from = request.args['magFrom'] if 'magFrom' in request.args else ''
    mag_to = request.args['magTo'] if 'magTo' in request.args else ''
    days = request.args['days'] if 'days' in request.args else ''
    latitude = request.args['lat'] if 'lat' in request.args else ''
    longitude = request.args['long'] if 'long' in request.args else ''
    distance = request.args['distance'] if 'distance' in request.args else ''
    CUR_cos_lat = ''
    CUR_sin_lat = ''
    CUR_cos_lng = ''
    CUR_sin_lng = ''
    cos_allowed_distance = ''
    if latitude and longitude and distance:
        CUR_cos_lat = math.cos(float(latitude) * math.pi / 180)
        CUR_sin_lat = math.sin(float(latitude) * math.pi / 180)
        CUR_cos_lng = math.cos(float(longitude) * math.pi / 180)
        CUR_sin_lng = math.sin(float(longitude) * math.pi / 180)
        cos_allowed_distance = math.cos(float(distance) / 6371) # This is in KM
        print("CUR_cos_lat: " + str(CUR_cos_lat))
        print("CUR_sin_lat: " + str(CUR_sin_lat))
        print("CUR_cos_lng: " + str(CUR_cos_lng))
        print("CUR_sin_lng: " + str(CUR_sin_lng))
        print("cos_allowed_distance: " + str(cos_allowed_distance))
    conn = get_connection()
    stmt = ibm_db.prepare(conn, 'SELECT "mytime", "latitude", "longitude", "depth", "mag", "magType", "nst", "gap", "dmin", "rms", "net", "id", "updated", "place", "type", "horizontalError", "depthError", "magError", "magNst", "status", "locationSource", "magSource", "RAD_LAT", "RAD_LONG", "COS_LAT", "SIN_LAT", "COS_LONG", "SIN_LONG" FROM "RNC42055"."EARTHQUAKE"')
    # stmt = ibm_db.prepare(conn, 'SELECT "mytime","latitude","longitude","depth","mag","rms","place" FROM earthquake WHERE (?='' or?='' or "mag" BETWEEN?AND?) AND (?='' OR?* "sin_lat"+?* "cos_lat" * ("cos_long"*?+"sin_long"*?)>?)')
    #(mag_from, mag_to, mag_from, mag_to, CUR_sin_lat, CUR_sin_lat, CUR_cos_lat, CUR_cos_lng, CUR_sin_lng, cos_allowed_distance)
    #stmt = ibm_db.prepare(conn, 'SELECT "mytime","latitude","longitude","depth","mag","rms","place" FROM "RNC42055"."EARTHQUAKE" WHERE "mag" BETWEEN '+ mag_from +' AND ' + mag_to)
    # ibm_db.bind_param(stmt, 1, mag_from)
    # ibm_db.bind_param(stmt, 2, mag_to)
    # ibm_db.bind_param(stmt, 3, mag_from)
    # ibm_db.bind_param(stmt, 4, mag_to)
    # ibm_db.bind_param(stmt, 5, CUR_sin_lat)
    # ibm_db.bind_param(stmt, 6, CUR_sin_lat)
    # ibm_db.bind_param(stmt, 7, CUR_cos_lat)
    # ibm_db.bind_param(stmt, 8, CUR_cos_lng)
    # ibm_db.bind_param(stmt, 9, CUR_sin_lng)
    # ibm_db.bind_param(stmt, 10, cos_allowed_distance)
    ibm_db.execute(stmt)
    my_tup = ibm_db.fetch_tuple(stmt)
    res = []
    while my_tup != False:
        res.append(my_tup)
        my_tup = ibm_db.fetch_tuple(stmt)
    print(res)
    return render_template('test2.html', result=res, content_type='application/json')


@application.route('/earthquake_mag', methods=['GET'])
def get_earthquakes_mag():
    mag_from = request.args['magFrom'] if 'magFrom' in request.args else ''
    mag_to = request.args['magTo'] if 'magTo' in request.args else ''
    days = request.args['days'] if 'days' in request.args else ''
    latitude = request.args['lat'] if 'lat' in request.args else ''
    longitude = request.args['long'] if 'long' in request.args else ''
    distance = request.args['distance'] if 'distance' in request.args else ''
    CUR_cos_lat = ''
    CUR_sin_lat = ''
    CUR_cos_lng = ''
    CUR_sin_lng = ''
    cos_allowed_distance = ''
    #calculation for distance
    if latitude and longitude and distance:
        CUR_cos_lat = math.cos(float(latitude) * math.pi / 180)
        CUR_sin_lat = math.sin(float(latitude) * math.pi / 180)
        CUR_cos_lng = math.cos(float(longitude) * math.pi / 180)
        CUR_sin_lng = math.sin(float(longitude) * math.pi / 180)
        cos_allowed_distance = math.cos(
            float(distance) / 6371)  # This is in KM
        print("CUR_cos_lat: " + str(CUR_cos_lat))
        print("CUR_sin_lat: " + str(CUR_sin_lat))
        print("CUR_cos_lng: " + str(CUR_cos_lng))
        print("CUR_sin_lng: " + str(CUR_sin_lng))
        print("cos_allowed_distance: " + str(cos_allowed_distance))
    conn = get_connection()
    #stmt = ibm_db.prepare(conn, 'SELECT "mytime", "latitude", "longitude", "depth", "mag", "magType", "nst", "gap", "dmin", "rms", "net", "id", "updated", "place", "type", "horizontalError", "depthError", "magError", "magNst", "status", "locationSource", "magSource", "RAD_LAT", "RAD_LONG", "COS_LAT", "SIN_LAT", "COS_LONG", "SIN_LONG" FROM "RNC42055"."EARTHQUAKE"')
    # stmt = ibm_db.prepare(conn, 'SELECT "mytime","latitude","longitude","depth","mag","rms","place" FROM earthquake WHERE (?='' or?='' or "mag" BETWEEN?AND?) AND (?='' OR?* "sin_lat"+?* "cos_lat" * ("cos_long"*?+"sin_long"*?)>?)')
    #(mag_from, mag_to, mag_from, mag_to, CUR_sin_lat, CUR_sin_lat, CUR_cos_lat, CUR_cos_lng, CUR_sin_lng, cos_allowed_distance)
    stmt = ibm_db.prepare(
        conn, 'SELECT "mytime","latitude","longitude","depth","mag","rms","place" FROM "RNC42055"."EARTHQUAKE" WHERE "mag" BETWEEN ' + mag_from + ' AND ' + mag_to)
    # ibm_db.bind_param(stmt, 3, mag_from)
    # ibm_db.bind_param(stmt, 4, mag_to)
    # ibm_db.bind_param(stmt, 5, CUR_sin_lat)
    # ibm_db.bind_param(stmt, 6, CUR_sin_lat)
    # ibm_db.bind_param(stmt, 7, CUR_cos_lat)
    # ibm_db.bind_param(stmt, 8, CUR_cos_lng)
    # ibm_db.bind_param(stmt, 9, CUR_sin_lng)
    # ibm_db.bind_param(stmt, 10, cos_allowed_distance)
    ibm_db.execute(stmt)
    my_tup = ibm_db.fetch_tuple(stmt)
    res = []
    while my_tup != False:
        res.append(my_tup)
        my_tup = ibm_db.fetch_tuple(stmt)
    print(res)
    return render_template('test.html', result=res, content_type='application/json')


#Clusters of earthquakes
@application.route('/clusters', methods=['GET'])
def get_clusters():
    cluster_count = int(request.args['cluster'])
    train_url = ""
    train = pd.read_sql_query("SELECT * FROM earthquake", get_connection())
    kmeans = KMeans(n_clusters=cluster_count)
    kmeans.fit(train[['longitude','latitude']])
    centroids = kmeans.cluster_centers_
    mydict = {i: np.where(kmeans.labels_ == i)[0] for i in range(3)}
    return render_template("results.html", mydict=mydict, centroids=centroids)

#Check if earthquakes occur more at night time
@application.route('/checknight', methods=['GET'])
def checknight():
    res = ''
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM earthquake WHERE TIME(time) BETWEEN '19:00:00' AND '24:00:00' AND mag > 4.0")
    night_count = cur.fetchone()
    cur.execute("SELECT COUNT(*) FROM earthquake WHERE TIME(time) BETWEEN '01:00:00' AND '18:00:00' AND mag > 4.0")
    day_count = cur.fetchone()
    if night_count > day_count:
        res = 'Large earthquakes occur more often at night'
    else:
        res = 'Large earthquakes occur more often in day time'
    return res


# Uploads CSV data into table
@application.route('/csv', methods=['POST'])
def upload_csv():
    file = request.files['csvFile']
    target = os.path.join(APP_ROOT, 'static')
    file.save(os.path.join(target, file.filename))
    f = open(os.path.join(target, file.filename), "r")
    reader = csv.DictReader( f, fieldnames = ( "time","latitude","longitude","depth","mag","magType","nst","gap","dmin","rms","net","id","updated","place","type","horizontalError","depthError","magError","magNst","status","locationSource","magSource"))
    conn = get_connection()
    next(reader, None)
    for row in reader:
        latitude = row['latitude'] if row['latitude'] else float(0)
        longitude = row['longitude'] if row['longitude'] else float(0)
        mytime = dateutil.parser.parse(row['time'])
        mytime = get_timezone_date(row['longitude'], row['latitude'], mytime.strftime("%Y-%m-%d %H:%M:%S.%f"))
        depth = row['depth'] if row['depth'] else float(0)
        mag = row['mag'] if row['mag'] else float(0)
        magType = row["magType"] if row["magType"] else ''
        nst = row["nst"] if row["nst"] else 0
        gap = row["gap"] if row["gap"] else float(0)
        dmin = row["dmin"] if row["dmin"] else 0
        rms = row["rms"] if row["rms"] else float(0)
        net = row["net"] if row["net"] else ''
        earthquake_id = row["id"] if row["id"] else ''
        updated = row["updated"] if row["updated"] else ''
        place = row["place"] if row["place"] else ''
        earthquake_type = row["type"] if row["type"] else ''
        horizontalError = row["horizontalError"] if row["horizontalError"] else 0
        depthError = row["depthError"] if row["depthError"] else 0
        magError = row["magError"] if row["magError"] else 0
        magNst = row["magNst"] if row["magNst"] else 0
        status = row["status"] if row["status"] else ''
        locationSource = row["locationSource"] if row["locationSource"] else ''
        magSource = row["magSource"] if row["magSource"] else ''
        #The calculations below are to check distance
        rad_lat = float(row['latitude'])
        rad_long = float(row['longitude'])
        cos_lat = math.cos(rad_lat * math.pi / 180)
        sin_lat = math.sin(rad_lat * math.pi / 180)
        cos_long = math.cos(rad_long * math.pi / 180)
        sin_long = math.sin(rad_long * math.pi / 180)
        sql = "INSERT INTO earthquake VALUES ( '" + mytime + "', " + str(latitude)+", "+str(longitude)+", "+str(depth)+", "+str(mag)+", '"+str(magType)+"', "+str(nst)+", "+str(gap)+", "+str(dmin)+", "+str(rms)+", '"+str(net)+"', '"+str(earthquake_id)+"', '"+str(updated)+"', '" + place + "', '"+str(
            earthquake_type)+"', "+str(horizontalError)+", "+str(depthError)+", "+str(magError)+", "+str(magNst)+", '"+str(status)+"', '"+str(locationSource)+"', '"+str(magSource)+"', "+str(rad_lat)+", "+str(rad_long)+", " + str(cos_lat)+", " + str(sin_lat)+", " + str(cos_long)+", " + str(sin_long) + ");"
        stmt1 = ibm_db.prepare(conn, sql)
        ibm_db.execute(stmt1)
    res = get_initial_data()
    return render_template("uploaded.html", result=res)

#Returns Count of rows, maximum magnitude and place with maximum magnitude
def get_initial_data():
    conn = get_connection()
    sql = 'SELECT COUNT(*), MAX("mag") FROM "RNC42055"."EARTHQUAKE";'
    stmt1 = ibm_db.prepare(conn, sql)
    ibm_db.execute(stmt1)
    res = ibm_db.fetch_assoc(stmt1)
    print(res)
    stmt2 = ibm_db.prepare(
        conn, 'SELECT "place" from "RNC42055"."EARTHQUAKE" where "mag" = '+str(res['2']))
    ibm_db.execute(stmt2)
    res2 = ibm_db.fetch_assoc(stmt2)
    print(res2)
    return [res['1'],res['2'],res2['place']]

# Template for all queries
@application.route('/getmaxearthquakes',methods=['GET'])
def get_max_earthquakes():
    conn = get_connection()
    sql = 'SELECT "mytime","latitude","longitude","depth","mag","rms","place" FROM "RNC42055"."EARTHQUAKE" ORDER BY "mag" LIMIT 5;'
    stmt = ibm_db.prepare(conn, sql)
    ibm_db.execute(stmt)
    res = []
    my_tup = ibm_db.fetch_tuple(stmt)
    while my_tup != False:
        res.append(my_tup)
        my_tup = ibm_db.fetch_tuple(stmt)
    print(res)
    return render_template('test.html', result=res)

@application.route('/question_eight',methods=['POST'])
def question_eight():
    place = request.args['my_place']
    updated_place = request.args['updated_place']
    to_be_deleted = true if 'to_be_deleted' in request.args else false
    if to_be_deleted:
        sql = 'DELETE FROM "RNC42055"."EARTHQUAKE" WHERE "mytime" IN(SELECT "mytime" FROM "RNC42055"."EARTHQUAKE" WHERE "place"="' + \
            place + '" ORDER BY "mytime" LIMIT 4;);'
    else:
        sql = 'UPDATE "RNC42055"."EARTHQUAKE" SET "place"="' + updated_place + \
            '" WHERE "mytime" IN(SELECT "mytime" FROM "RNC42055"."EARTHQUAKE" WHERE "place"="' + \
            place + '" ORDER BY "mytime" LIMIT 4;);'
    conn = get_connection()
    stmt = ibm_db.prepare(conn, sql)
    ibm_db.execute(stmt)
    sql2 = 'SELECT "mytime","latitude","longitude","depth","mag","rms","place" FROM "RNC42055"."EARTHQUAKE" WHERE "place"="' + \
        updated_place+'" ORDER BY "mytime" LIMIT 4;'
    stmt2 = ibm_db.prepare(conn, sql2)
    ibm_db.execute(stmt2)
    res = []
    my_tup = ibm_db.fetch_tuple(stmt2)
    while my_tup != False:
        res.append(my_tup)
        my_tup = ibm_db.fetch_tuple(stmt2)
    print(res)
    return render_template('test.html', result=res)

#Gets date from timezone with longitude and latitude
def get_timezone_date(longitude, latitude, dt):
    datetime_obj_naive = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S.%f")
    mytimezone = tf.timezone_at(lng=float(longitude), lat=float(latitude))
    if not mytimezone:
        return datetime_obj_naive.strftime(fmt)[:-3]
    utcmoment = datetime_obj_naive.replace(tzinfo=pytz.utc)
    localDatetime = utcmoment.astimezone(pytz.timezone(str(mytimezone)))
    return localDatetime.strftime(fmt)[:-3]

#Cleans table
@application.route('/delete', methods=['GET'])
def deleteall():
    conn = get_connection()
    stmt = ibm_db.prepare(conn,"DELETE FROM earthquake")
    ibm_db.execute(stmt)
    ibm_db.commit(conn)
    return "Successfully deleted all data"

#Step counter range for magnitude values
# @application.route('/magrange', methods=['GET'])
# def mag_range():
#     mag_from = request.args['magFrom'] if 'magFrom' in request.args else ''
#     mag_to = request.args['magTo'] if 'magTo' in request.args else ''
#     if mag_from and mag_to:
#         mag_from = float(mag_from)
#         mag_to = float(mag_to)
#         my_range = numpy.arange(mag_from, mag_to, 0.1)
#         i = 0
#         myres = []
#         conn = get_connection()
#         while i < len(my_range):
#             if(i+1 >= len(my_range)):
#                 break
#             stmt = ibm_db.prepare(
#                     conn, 'SELECT "mytime","latitude","longitude","depth","mag","rms","place" FROM "RNC42055"."EARTHQUAKE" WHERE "mag" BETWEEN '+ str(i) +' AND '+ str(i+1))
#             ibm_db.execute(stmt)
#             my_tup = ibm_db.fetch_assoc(stmt)
#             while my_tup != False:
#                 myres.append([my_tup['mag'],i , i+1])
#                 my_tup = ibm_db.fetch_assoc(stmt)
#             i = i + 1
#         return render_template("test2.html", result=myres)
#     return ""

#Gets the number of rows deleted based on the query
@application.route('/deleteme', methods=['GET'])
def dele():
    mag_from = request.args['magFrom'] if 'magFrom' in request.args else ''
    mag_to = request.args['magTo'] if 'magTo' in request.args else ''
    mydate = request.args['date'] if 'date' in request.args else ''
    mydate = dateutil.parser.parse(mydate).strftime("%Y-%m-%d %H:%M:%S")
    print(mydate)
    conn = get_connection()
    cur = conn.cursor()
    res2 = cur.execute("SELECT * FROM earthquake")
    cur.execute("DELETE FROM earthquake where time = %s and mag between %s and %s", (mydate, mag_from, mag_to))
    cur.execute("SELECT ROW_COUNT()")
    res = cur.fetchall()
    conn.commit()
    return render_template("test3.html", result=res)

# App starts here
if __name__ == '__main__':
    application.run(host='0.0.0.0', port=port, debug=True)
